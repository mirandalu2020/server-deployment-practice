# server-deployment-practice

## Deployed Link

https://server-dev-practice.onrender.com

1. Install the dependencies needed
2. Set up .github folder, along with node.yml
3. Make sure the package.json has the script section set up

## Running the App

To run the app, type `npm run start` in your terminal (entry point: server.js)
