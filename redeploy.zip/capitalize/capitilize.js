function capitalize(string) {
  return string.toUpperCase();
}

// exports code to another file if needed.
module.exports = capitalize;